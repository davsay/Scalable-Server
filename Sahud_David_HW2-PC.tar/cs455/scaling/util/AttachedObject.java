package cs455.scaling.util;


public class AttachedObject
{
	int value;
	public AttachedObject()
	{
		//this.channel = channel;
	}

}